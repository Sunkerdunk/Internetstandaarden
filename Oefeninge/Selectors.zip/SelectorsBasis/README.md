We gaan aan de slag met CSS selectors. Je mag naar de HTML kijken maar je mag er niks aan aanpassen. Je mag voor deze opdracht **alleen CSS gebruiken**.

## Selectors

De tekst in de lijstjes zegt eigenlijk al een beetje wat de bedoeling is. Gebruik de juiste CSS selector om het juiste element een kleur te geven. Doe ze stuk voor stuk want wat er waarschijnlijk gaat gebeuren is dat elementen kleur gaan krijgen
waarvan je niet wilt dat ze kleur gaan krijgen. Dus soms moet je _'oude' code in comments zetten_ om ervoor te zorgen dat je niet CSS overschrijft.

De laatste is minder voor de hand liggend. Kan je die ook oplossen?